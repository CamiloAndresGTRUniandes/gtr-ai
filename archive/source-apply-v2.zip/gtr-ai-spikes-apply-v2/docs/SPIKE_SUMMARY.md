# Apply spike summary

All 20 planned spikes are tracked. Eleven native test-runner tests passed; additional assertions and an offline npm smoke test completed. Five spikes have partial positive evidence; fifteen remain blocked against full acceptance criteria. No spike is fully validated.

| ID | Component | Status | Evidence / limitation |
|---|---|---|---|
| SPK-001 | Platform foundation | BLOCKED | Node 22.16, npm 10.9.2, native SQLite 3.49.1 and FTS5 verified; npm registry lookup failed with EAI_AGAIN. |
| SPK-002 | Pi runtime | BLOCKED | Pi executable absent; registry inaccessible. No SDK or RPC experiment. |
| SPK-003 | TUI | BLOCKED | Pi unavailable; no terminal layout or extension test. Empty Node process timing is not TUI timing. |
| SPK-004 | LangGraph | BLOCKED | Mock four-phase state machine passed gates, bounded rework, reopen; committed approval survived SIGKILL. No LangGraph code executed. |
| SPK-005 | Declarative workflow | BLOCKED | JSON-object graph validator detects missing dependencies, cycles and approval override. No YAML parsing or LangGraph compilation. |
| SPK-006 | Daemon and IPC | PASSED_WITH_LIMITATIONS | Actual Unix socket: two clients, token rejection, duplicate suppression, 200 round trips; separate process socket connectivity also demonstrated. |
| SPK-007 | SQLite persistence | PASSED_WITH_LIMITATIONS | Actual WAL reader isolation, commit, rollback, integrity check and uncommitted transaction killed with SIGKILL; FTS5 works. |
| SPK-008 | Hybrid RAG | BLOCKED | Actual FTS5 scoped search of 10,004 records; synthetic rank fusion arithmetic passes. No embeddings or vector extension. |
| SPK-009 | Decision management | PASSED_WITH_LIMITATIONS | Scoped FTS5 excludes superseded decision and other project in fixture. No semantic contradiction evaluation or approval lifecycle. |
| SPK-010 | Provider authentication | BLOCKED | Mock accounts enforce project/provider authorization and paid opt-in. No actual credentials or provider requests. |
| SPK-011 | Copilot Fusion | BLOCKED | No Pi extension installed; no account authorization or live request. |
| SPK-012 | Adaptive routing | BLOCKED | Deterministic baseline tested with 4 and 100 mock accounts; affinity and paid opt-in pass. No third-party router or task quality benchmark. |
| SPK-013 | Ponytail | BLOCKED | No upstream skill fetched or executed; no quality/token A/B benchmark. |
| SPK-014 | Context engineering | PASSED_WITH_LIMITATIONS | Synthetic exact dedup and byte-budget selection passed; same-serialization dedup 21,751 to 4,351 bytes. |
| SPK-015 | RTK | BLOCKED | RTK absent; no command filtering executed. |
| SPK-016 | Graphify | BLOCKED | Graphify absent; Python exists but no upstream package downloaded. |
| SPK-017 | Git worktrees | PASSED_WITH_LIMITATIONS | Actual parallel writes in separate Git worktrees, independent merge, real merge conflict and cleanup; dirty tracked and untracked original files preserved. |
| SPK-018 | Host integrations | BLOCKED | Codex executable absent; no VS Code, Claude Code or Pi host exercised. |
| SPK-019 | Azure DevOps, security, distribution | BLOCKED | Mock external reconciliation avoids duplicate creation; actual symlink escape check rejects existing path. Local offline npm pack/install/execute/uninstall passed. No Azure API or native dependency provisioning. |
| SPK-020 | Walking skeleton | BLOCKED | Mock vertical fixture retrieves a decision, routes, persists four approval states and completes. Separate tests exercise worktrees and SQLite. No real agent integration. |

## Supplemental Apply evidence

Iteration 2 adds seven passing local tests. See [Apply iteration 2](APPLY_ITERATION_2.md). The original status classification remains unchanged.
