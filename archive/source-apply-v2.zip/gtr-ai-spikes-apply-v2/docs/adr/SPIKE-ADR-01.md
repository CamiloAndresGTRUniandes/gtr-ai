# SPIKE-ADR-01: Native SQLite first

Status: Proposed — requires human approval after Verify. These IDs are experimental and do not replace existing project ADRs.

## Decision
Evaluate node:sqlite before adding a binding.

## Evidence
WAL, rollback and crash recovery passed on Node 22.16; FTS5 is enabled.

## Alternatives
better-sqlite3; separate persistence adapters

## Consequences and residual risks
sqlite-vec and LangGraph integration, target Node 24 and platform validation outstanding.

## Validation
See corresponding spike reports; repeat on target platforms and actual dependencies before production adoption.
