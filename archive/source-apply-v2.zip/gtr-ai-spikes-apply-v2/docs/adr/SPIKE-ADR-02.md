# SPIKE-ADR-02: Local IPC daemon candidate

Status: Proposed — requires human approval after Verify. These IDs are experimental and do not replace existing project ADRs.

## Decision
Continue with an on-demand daemon candidate using local IPC.

## Evidence
Unix sockets worked within and across processes.

## Alternatives
Independent processes; authenticated loopback

## Consequences and residual risks
Windows named pipes, ownership, authentication and lifecycle unverified.

## Validation
See corresponding spike reports; repeat on target platforms and actual dependencies before production adoption.
