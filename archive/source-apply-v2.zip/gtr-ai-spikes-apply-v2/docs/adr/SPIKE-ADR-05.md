# SPIKE-ADR-05: Git worktree isolation

Status: Proposed — requires human approval after Verify. These IDs are experimental and do not replace existing project ADRs.

## Decision
Keep worktrees for concurrent code tasks.

## Evidence
Real independent merge and conflict; dirty original preserved.

## Alternatives
Sequential edits; separate clones

## Consequences and residual risks
Cross-platform recovery and sandbox boundaries remain unverified.

## Validation
See corresponding spike reports; repeat on target platforms and actual dependencies before production adoption.
