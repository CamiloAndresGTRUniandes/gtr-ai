# SPIKE-ADR-06: External side effects

Status: Proposed — requires human approval after Verify. These IDs are experimental and do not replace existing project ADRs.

## Decision
Persist intent, reconcile uncertain outcomes, fail closed.

## Evidence
Mock duplicate suppression and unknown-outcome refusal.

## Alternatives
Blind retries

## Consequences and residual risks
Real API idempotency and durable journal not tested.

## Validation
See corresponding spike reports; repeat on target platforms and actual dependencies before production adoption.
