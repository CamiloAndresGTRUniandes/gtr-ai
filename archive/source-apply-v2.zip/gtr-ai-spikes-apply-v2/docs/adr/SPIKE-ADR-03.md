# SPIKE-ADR-03: Deterministic routing policy layer

Status: Proposed — requires human approval after Verify. These IDs are experimental and do not replace existing project ADRs.

## Decision
Keep authorization, capability filtering and paid opt-in deterministic.

## Evidence
Synthetic routing tests and latency benchmarks passed.

## Alternatives
Third-party-only router; model classifier

## Consequences and residual risks
Real provider credentials, quota behavior and candidate quality are unverified.

## Validation
See corresponding spike reports; repeat on target platforms and actual dependencies before production adoption.
