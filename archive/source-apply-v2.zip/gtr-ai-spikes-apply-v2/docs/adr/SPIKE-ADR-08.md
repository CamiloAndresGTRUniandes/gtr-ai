# SPIKE-ADR-08 — Preserve interrupted worktrees

Status: Proposed; pending Verify and approval.

Decision: Retain dirty worktrees after cancellation or crashes. Record baseline and task ownership; reconcile before cleanup. Never force-remove user changes by default.

Alternatives: Automatic forced cleanup; immediate reset. These risk losing partial work.

Evidence: `spikes/followup.mjs` SPK-017; real Git and SIGKILL on Linux. Dirty removal rejected, original repository unchanged.

Consequences: Disk retention and explicit recovery policy required. Git worktrees are not security sandboxes.

Validation: Windows locking, macOS, orphan handling, scheduler crash and cleanup ownership.
