# SPIKE-ADR-09 — Mandatory context and provenance

Status: Proposed; pending Verify and approval.

Decision: Deduplicate exact content while retaining all source references and mandatory flags. If mandatory context exceeds the budget, suspend or request a larger budget instead of silently dropping it.

Alternatives: Truncate indiscriminately; summarize mandatory constraints automatically.

Evidence: `spikes/followup.mjs` SPK-014; deterministic byte-budget fixture passed.

Consequences: Requires explicit mandatory metadata and model-aware token accounting. No model quality or token savings proven.

Validation: Real provider tokenizers, prompt caching, source authorization, conflicting metadata and task-success evaluation.
