# SPIKE-ADR-04: Selective context and lexical retrieval

Status: Proposed — requires human approval after Verify. These IDs are experimental and do not replace existing project ADRs.

## Decision
Use exact dedup, explicit scope/status and lexical search baseline.

## Evidence
FTS5 and synthetic byte reduction tests passed.

## Alternatives
Vector-only search; full context injection

## Consequences and residual risks
No real token savings or semantic retrieval quality measured.

## Validation
See corresponding spike reports; repeat on target platforms and actual dependencies before production adoption.
