# GTR-AI — Architecture Spikes / Apply evidence

Experimental package only. Intended repository: `D:\GTR-AI`. No files were written to the user's machine. Merge directories into the repository after reviewing existing files; do not overwrite canonical documentation. This package does not contain production implementation or approved ADRs.

## Reproduce on Linux

Requires Node.js 22.16+ with experimental `node:sqlite`, Git, npm and Bash. No external packages or provider accounts needed for these experiments. From this directory:

```bash
node --test spikes/experiments.mjs
node spikes/additional.mjs
bash spikes/npm-smoke.sh
```

The first command overwrites `docs/benchmarks/raw-results/local.json`. To regenerate the additional report, redirect standard output to `docs/benchmarks/raw-results/additional.json`. Preserve the supplied original evidence before rerunning if needed. These scripts create disposable temporary repositories and databases. SIGKILL and Unix socket tests are Linux-oriented; Windows and macOS results are not claimed.

## Read first

- `docs/SPIKE_SUMMARY.md`: status of all 20 spikes.
- `docs/IMPLEMENTATION_READINESS.md`: blockers and next steps.
- `docs/benchmarks/summary.md`: measured results and caveats.
- `docs/spikes/`: individual English reports.
- `docs/adr/`: proposed experimental ADRs.
- `evidence/`: captured test output and environment diagnostics.

Research was approved; Apply was executed within the available environment. Verify and Archive remain formal human-approved phases. No paid or subscription calls were made.

## Apply iteration 2

See `docs/APPLY_ITERATION_2.md` for seven additional tests, limits and three proposed ADRs. Reproduce on Linux with `node --test spikes/followup.mjs` (overwrites followup benchmark JSON). Original evidence and original spike status table are preserved.
